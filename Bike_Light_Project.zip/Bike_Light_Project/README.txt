Bike Light Project (Arduino Nano)
=================================

Connections:
- Left Button: D2
- Right Button: D3
- Headlight Button: D4
- LED Strip (WS2812): D6
- LCD I2C: SDA -> A4, SCL -> A5
- Voltage Divider Output -> A0

Libraries required:
- Adafruit_NeoPixel
- LiquidCrystal_I2C

Functionality:
- 3 buttons control left/right indicators and headlight toggle
- WS2812 LEDs used for indicators + tail light
- LCD shows live battery voltage (simple text)
- Tail light steady ON, blinks during signaling
